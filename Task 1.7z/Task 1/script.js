/* ------------------------------ TASK 1 ----------------------------
Parašykite JS kodą, kuris leis vartotojui įvesti svorį kilogramais ir
pamatyti jo pateikto svorio kovertavimą į:
1. Svarus (lb) | Formulė: lb = kg * 2.2046
2. Gramus (g) | Formulė: g = kg / 0.0010000
3. Uncijos (oz) | Formul4: oz = kg * 35.274

Pastaba: atvaizdavimas turi būti matomas pateikus formą ir pateikiamas
<div id="output"></div> viduje, bei turi turėti bent minimalų stilių;
------------------------------------------------------------------- */

let weight = document.getElementById("search").value;
const form = document.querySelector("form");

// const value = 2;
// if (typeof weight === "number") {
//   console.log(value);
// }

function handleFormSubmit(event) {
  event.preventDefault();

  let pounds = weight * 2.2046;
  let grams = weight / 0.01;
  let oz = weight * 35.274;

  //   console.log(pounds, grams, oz);
  document.getElementById("pounds").textContent = pounds;
  document.getElementById("grams").textContent = grams;
  document.getElementById("oz").textContent = oz;
}

form.addEventListener("submit", handleFormSubmit);
