/* ------------------------------ TASK 8 --------------------------------------------
Sukurkite konstruktoriaus funkciją "Calculator" (naudokite ES5), kuri gebės sukurti objektus su 4 metodais:
sum(a, b) - priima du skaičius ir grąžina jų sumą.
subtraction(a, b) - priima du skaičius ir grąžina jų skirtumą.
multiplication(a, b) - priima du skaičius ir grąžina jų daugybos rezultatą;
division(a, b) - priima du skaičius ir grąžina jų dalybos rezultatą;
------------------------------------------------------------------------------------ */

let pirmas = document.getElementById("pirmas").value;
let antras = document.getElementById("antras").value;
const form = document.querySelector("form");
let calculation = document.getElementById("calculation");

function handleFormSubmit(event) {
  event.preventDefault();
  let sumuoja = pirmas + antras;
  let subtract = pirmas - antras;
  let multiply = pirmas * antras;
  let divide = pirmas / antras;
  console.log(sumuoja, subtract, multiply, divide);
  document.getElementById("sum").textContent = sumuoja;
  document.getElementById("subtract").textContent = subtract;
  document.getElementById("multiply").textContent = multiply;
  document.getElementById("divide").textContent = divide;
}

form.addEventListener("submit", handleFormSubmit);
